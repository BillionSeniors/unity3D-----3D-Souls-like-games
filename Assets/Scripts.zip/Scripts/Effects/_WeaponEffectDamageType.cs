using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace QHZ
{
    public class _WeaponEffectDamageType : MonoBehaviour
    {
        public _EffectWeaponDamageType _effectWeaponDamageType;
    }
}