using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace QHZ
{
    public class EffectParticle : MonoBehaviour
    {
        public EffectParticleType effectType;
    }
}