using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace QHZ
{
    public class ShopInteractable : Interactable
    {
        public override void Interact(PlayerManager playerManager)
        {
            playerManager.uiManager.shopWindow.SetActive(true);
            playerManager.interactableUIGameObject.SetActive(false);
            playerManager.itemInteractableGameObject.SetActive(false);
        }
    }
}