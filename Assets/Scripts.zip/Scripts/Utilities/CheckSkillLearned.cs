using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace QHZ
{
    public class CheckSkillLearned : MonoBehaviour
    {
        //Talent talent;

        //private void Awake()
        //{
        //    talent = FindObjectOfType<Talent>();

        //    if (talent != null)
        //    {
        //        talent._InstantiateTalents();
        //    }
        //    else
        //    {
        //        Debug.Log("CANNOT CHECK");
        //    }
        //}
    }
}