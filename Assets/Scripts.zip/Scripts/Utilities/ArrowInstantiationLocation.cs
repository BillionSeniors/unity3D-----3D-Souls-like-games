using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ArrowInstantiationLocation : MonoBehaviour
{
    //this script help spawn arrow
}
