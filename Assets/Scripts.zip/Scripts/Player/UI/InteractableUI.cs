using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace QHZ
{
    public class InteractableUI : MonoBehaviour
    {
        public Text interactableText;

        public Text itemText;
        public RawImage itemImage;
    }
}