using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace QHZ
{
    public class AICharacterLocomotionManager : CharacterLocomotionManager
    {

    }
}