using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace QHZ
{
    public class AICharacterAction : ScriptableObject
    {
        public string actionAnimation;
        public bool isRightHandedAction = true;
    }
}