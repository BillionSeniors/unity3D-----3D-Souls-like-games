using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace QHZ
{
    public class ItemAction : ScriptableObject
    {
        public virtual void PerformAction(CharacterManager player)
        {

        }
    }
}
